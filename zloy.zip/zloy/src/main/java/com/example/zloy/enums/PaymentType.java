package com.example.zloy.enums;

public enum PaymentType {
    ПОПОЛНЕНИЕ("пополнение"),
    СПИСАНИЕ("списание"),
    ВОЗВРАТ("возврат");

    private final String value;

    PaymentType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static PaymentType fromValue(String value) {
        for (PaymentType type : values()) {
            if (type.getValue().equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }
}
