package com.example.zloy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class TariffChangeService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void changeTariff(int userId, String newTariff) {
        String sql = "SELECT tariff_change(?, ?)";
        jdbcTemplate.update(sql, userId, newTariff);
    }

    public void changeTariffById(int userId, int newTariffId) {
        String sql = "SELECT tariff_change(?, ?)";
        jdbcTemplate.update(sql, userId, newTariffId);
    }
}
