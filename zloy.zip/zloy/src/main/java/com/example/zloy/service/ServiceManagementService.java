package com.example.zloy.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ServiceManagementService {

    private final JdbcTemplate jdbcTemplate;

    public ServiceManagementService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void addService(int userId, int serviceId) {
        String sql = "SELECT add_service(?, ?)";
        jdbcTemplate.update(sql, userId, serviceId);
    }
}

