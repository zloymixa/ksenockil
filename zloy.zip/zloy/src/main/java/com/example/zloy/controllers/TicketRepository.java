package com.example.zloy.controllers;

import com.example.zloy.entities.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;


public interface TicketRepository extends JpaRepository<Ticket, Long> {

    // Метод для получения всех тикетов по статусу
    List<Ticket> findByStatus(String status);

    // Метод для поиска тикета по пользователю
    List<Ticket> findByUserId(Long userId);

    // Метод для получения тикета по ID
    Optional<Ticket> findById(Long id);
}