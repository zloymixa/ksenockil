package com.example.zloy.service;

import com.example.zloy.entities.AdditionalService;
import com.example.zloy.service.AdditionalServiceService;
import com.example.zloy.controllers.AdditionalServiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdditionalServiceServiceImpl implements AdditionalServiceService {

    private final AdditionalServiceRepository repository;


    public AdditionalServiceServiceImpl(AdditionalServiceRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<AdditionalService> getAll() {
        return repository.findAll();
    }

    @Override
    public AdditionalService getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Доп. услуга не найдена"));
    }

    @Override
    public AdditionalService create(AdditionalService service) {
        AdditionalService savedService = repository.save(service);
        System.out.println("Service saved: " + savedService);
        return savedService;
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public AdditionalService update(Long id, AdditionalService updatedService) {
        AdditionalService existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Доп. услуга не найдена"));

        existing.setName(updatedService.getName());
        existing.setDescription(updatedService.getDescription());
        existing.setPrice(updatedService.getPrice());

        return repository.save(existing);
    }


}
