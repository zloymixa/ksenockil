package com.example.zloy.controller;

import com.example.zloy.entities.AdditionalService;
import com.example.zloy.service.AdditionalServiceService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/additional-services")
public class AdditionalServiceController {

    private final AdditionalServiceService service;

    public AdditionalServiceController(AdditionalServiceService service) {
        this.service = service;
    }

    @GetMapping
    public List<AdditionalService> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public AdditionalService getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public AdditionalService create(@RequestBody AdditionalService additionalService) {
        return service.create(additionalService);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
    @PutMapping("/{id}")
    public AdditionalService update(@PathVariable Long id, @RequestBody AdditionalService updatedService) {
        return service.update(id, updatedService);
    }

}
