package com.example.zloy.controller;


import com.example.zloy.entities.TariffService;
import com.example.zloy.service.TariffServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/tariff-services")

public class TariffServiceController {

    private final TariffServiceService tariffServiceService;

    @Autowired
    public TariffServiceController(TariffServiceService tariffServiceService) {
        this.tariffServiceService = tariffServiceService;
    }

    @PostMapping("/add/{tariffId}/{serviceId}")
    public ResponseEntity<TariffService> addServiceToTariff(@PathVariable Long tariffId, @PathVariable Long serviceId) {
        TariffService tariffService = tariffServiceService.addServiceToTariff(tariffId, serviceId);
        return new ResponseEntity<>(tariffService, HttpStatus.CREATED);
    }

    @DeleteMapping("/remove/{tariffServiceId}")
    public ResponseEntity<Void> removeServiceFromTariff(@PathVariable Long tariffServiceId) {
        tariffServiceService.removeServiceFromTariff(tariffServiceId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/tariff/{tariffId}")
    public List<TariffService> getServicesByTariff(@PathVariable Long tariffId) {
        return tariffServiceService.getServicesByTariff(tariffId);
    }

    @GetMapping("/service/{serviceId}")
    public List<TariffService> getTariffsByService(@PathVariable Long serviceId) {
        return tariffServiceService.getTariffsByService(serviceId);
    }
}
