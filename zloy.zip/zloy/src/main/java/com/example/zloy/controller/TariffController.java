package com.example.zloy.controller;

import com.example.zloy.entities.Tariff;
import com.example.zloy.service.TariffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tariffs")
public class TariffController {

    private final TariffService tariffService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public TariffController(TariffService tariffService) {
        this.tariffService = tariffService;
    }

    @GetMapping
    public List<Tariff> getAllTariffs() {
        return tariffService.getAllTariffs();
    }


    @GetMapping("/{id}")
    public ResponseEntity<Tariff> getTariffById(@PathVariable Long id) {
        Tariff tariff = tariffService.getTariffById(id).orElseThrow(() -> new RuntimeException("Тариф не найден"));
        return ResponseEntity.ok(tariff);
    }

    @PostMapping
    public Tariff createTariff(@RequestBody Tariff tariff) {
        return tariffService.createTariff(tariff);
    }

    @PutMapping("/{id}")
    public Tariff updateTariff(@PathVariable Long id, @RequestBody Tariff tariff) {
        return tariffService.updateTariff(id, tariff);
    }

    @DeleteMapping("/{id}")
    public void deleteTariff(@PathVariable Long id) {
        tariffService.deleteTariff(id);
    }

    @GetMapping("/popular")
    public List<Map<String, Object>> getMostPopularTariffs() {
        String query = "SELECT * FROM sim_operator_system.get_most_popular_tariffs()";  // Вызываем функцию

        // Выполняем запрос и получаем результат
        return jdbcTemplate.queryForList(query);
    }
}
