package com.example.zloy.converters;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import com.example.zloy.enums.PaymentType;

@Converter(autoApply = true)
public class PaymentTypeConverter implements AttributeConverter<PaymentType, String> {

    @Override
    public String convertToDatabaseColumn(PaymentType attribute) {
        return attribute != null ? attribute.getValue() : null;
    }

    @Override
    public PaymentType convertToEntityAttribute(String dbData) {
        return dbData != null ? PaymentType.fromValue(dbData) : null;
    }
}