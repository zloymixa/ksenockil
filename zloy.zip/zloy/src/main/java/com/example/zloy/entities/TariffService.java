package com.example.zloy.entities;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.math.BigDecimal;

@Entity
@Table(name = "tariff_services", schema = "sim_operator_system")
public class TariffService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "tariff_id", referencedColumnName = "id", nullable = false)
    private Tariff tariff;

    @ManyToOne
    @JoinColumn(name = "service_id", referencedColumnName = "id", nullable = true)  // Услуга может быть null
    private AdditionalService service;

    // Конструкторы
    public TariffService() {
    }

    public TariffService(Tariff tariff, AdditionalService service) {
        this.tariff = tariff;
        this.service = service;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    public AdditionalService getService() {
        return service;
    }

    public void setService(AdditionalService service) {
        this.service = service;
    }

    @Override
    public String toString() {
        return "TariffService{" +
                "id=" + id +
                ", tariff=" + tariff.getId() +
                ", service=" + (service != null ? service.getId() : "null") +
                '}';
    }

}
