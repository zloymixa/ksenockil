package com.example.zloy.service;

import com.example.zloy.entities.RegistrationRequest;
import com.example.zloy.controllers.RegistrationRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegistrationRequestService {

    private final RegistrationRequestRepository registrationRequestRepository;
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public RegistrationRequestService(RegistrationRequestRepository registrationRequestRepository, JdbcTemplate jdbcTemplate) {
        this.registrationRequestRepository = registrationRequestRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    public RegistrationRequest createRegistrationRequest(RegistrationRequest request) {
        return registrationRequestRepository.save(request);
    }

    public RegistrationRequest getRegistrationRequestById(Integer id) {
        return registrationRequestRepository.findById(id).orElse(null);
    }

    public List<RegistrationRequest> getAllRegistrationRequests() {
        return registrationRequestRepository.findAll();
    }

    public String registerUserFromRequest(Integer id) {
        try {
            return jdbcTemplate.queryForObject(
                    "SELECT sim_operator_system.register_user_from_request(?)::text",
                    String.class,
                    id
            );
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"success\": false, \"message\": \"Ошибка при регистрации: " + e.getMessage().replace("\"", "\\\"") + "\"}";
        }
    }
}
