package com.example.zloy.controllers;

import com.example.zloy.entities.QrPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface QrPaymentRepository extends JpaRepository<QrPayment, Long> {
    Optional<QrPayment> findByConfirmationCodeAndIsPaidFalse(String confirmationCode);
    Optional<QrPayment> findFirstByUserIdAndIsPaidFalseOrderByCreatedAtDesc(Long userId);

}