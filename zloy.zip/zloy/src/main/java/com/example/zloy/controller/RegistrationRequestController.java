package com.example.zloy.controller;

import com.example.zloy.entities.RegistrationRequest;
import com.example.zloy.service.RegistrationRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/registration-requests")
public class RegistrationRequestController {

    private final RegistrationRequestService registrationRequestService;

    @Autowired
    public RegistrationRequestController(RegistrationRequestService registrationRequestService) {
        this.registrationRequestService = registrationRequestService;
    }

    @PostMapping
    public ResponseEntity<?> createRegistrationRequest(@RequestBody RegistrationRequest request) {
        RegistrationRequest savedRequest = registrationRequestService.createRegistrationRequest(request);
        return ResponseEntity.ok().body(
                java.util.Collections.singletonMap("id", savedRequest.getId())
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getRegistrationRequest(@PathVariable Integer id) {
        RegistrationRequest request = registrationRequestService.getRegistrationRequestById(id);
        if (request != null) {
            return ResponseEntity.ok(request);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<?> getAllRegistrationRequests() {
        return ResponseEntity.ok(registrationRequestService.getAllRegistrationRequests());
    }

    @PostMapping("/register/{id}")
    public ResponseEntity<?> registerUserFromRequest(@PathVariable Integer id) {
        String result = registrationRequestService.registerUserFromRequest(id);

        // Вернем строку JSON прямо в теле ответа
        return ResponseEntity.ok().body(result);
    }
}
