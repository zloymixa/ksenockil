package com.example.zloy.controller;

import com.example.zloy.entities.User;
import com.example.zloy.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import java.sql.Timestamp;



import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public UserController(UserService userService, JdbcTemplate jdbcTemplate) {
        this.userService = userService;
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping("/report")
    public ResponseEntity<Map<String, Object>> getUserReport() {
        String query = "SELECT * FROM sim_operator_system.generate_user_report()";

        try {
            Map<String, Object> result = jdbcTemplate.queryForObject(query, (rs, rowNum) -> {
                Map<String, Object> report = new LinkedHashMap<>();

                report.put("total_users", rs.getInt("total_users"));
                report.put("most_popular_letter", rs.getString("most_popular_letter"));
                report.put("least_popular_letter", rs.getString("least_popular_letter"));
                report.put("avg_first_name_length", rs.getDouble("avg_first_name_length"));
                report.put("avg_last_name_length", rs.getDouble("avg_last_name_length"));
                report.put("most_popular_email_domain", rs.getString("most_popular_email_domain"));
                report.put("most_popular_first_name", rs.getString("most_popular_first_name"));
                report.put("least_popular_first_name", rs.getString("least_popular_first_name"));
                report.put("most_popular_last_name", rs.getString("most_popular_last_name"));
                report.put("least_popular_last_name", rs.getString("least_popular_last_name"));

                return report;
            });

            return ResponseEntity.ok(result);

        } catch (EmptyResultDataAccessException e) {
            return ResponseEntity.notFound().build();
        } catch (DataAccessException e) {
            return ResponseEntity.internalServerError().body(
                    Map.of("error", "Failed to generate report",
                            "details", e.getMostSpecificCause().getMessage()));
        }
    }

    // Остальные методы остаются без изменений
    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public Optional<User> getUserById(@PathVariable Long id) {
        return userService.getUserById(id);
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        System.out.println("Получен пользователь: " + user);
        return userService.saveUser(user);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        Optional<User> optionalUser = userService.getUserById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setFirstName(updatedUser.getFirstName());
            existingUser.setLastName(updatedUser.getLastName());
            existingUser.setEmail(updatedUser.getEmail());
            return userService.saveUser(existingUser);
        } else {
            throw new RuntimeException("Пользователь с id " + id + " не найден.");
        }
    }
}