package com.example.zloy.enums;

public enum AdminActionType {

    ИЗМЕНЕНИЕ_ТАРИФА("изменение тарифа"),
    ДОБАВЛЕНИЕ_УСЛУГИ("добавление услуги"),
    УДАЛЕНИЕ_УСЛУГИ("удаление услуги"),
    ДОБАВЛЕНИЕ_ПОЛЬЗОВАТЕЛЯ("добавление пользователя"),
    УДАЛЕНИЕ_ПОЛЬЗОВАТЕЛЯ("удаление пользователя");

    private final String value;

    AdminActionType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static AdminActionType fromValue(String value) {
        for (AdminActionType type : values()) {
            if (type.value.equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown action type: " + value);
    }
}