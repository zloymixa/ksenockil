package com.example.zloy.controller;

import com.example.zloy.dto.SimCardStatisticsDto;
import com.example.zloy.entities.SimCard;
import com.example.zloy.entities.Tariff;
import com.example.zloy.service.SimCardService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/sim-cards")  // Основной путь для всех маршрутов в контроллере
public class SimCardController {

    private final SimCardService simCardService;

    public SimCardController(SimCardService simCardService) {
        this.simCardService = simCardService;
    }

    // Получить все SIM-карты
    @RequestMapping(method = RequestMethod.GET)
    public List<SimCard> getAllSimCards() {
        return simCardService.getAllSimCards();
    }

    // Получить SIM-карты по пользователю
    @RequestMapping(value = "/user/{userId}", method = RequestMethod.GET)
    public List<SimCard> getSimCardsByUser(@PathVariable Long userId) {
        return simCardService.getSimCardsByUser(userId);
    }

    // Получить SIM-карты по тарифу
    @RequestMapping(value = "/tariff/{tariffId}", method = RequestMethod.GET)
    public List<SimCard> getSimCardsByTariff(@PathVariable Long tariffId) {
        return simCardService.getSimCardsByTariff(tariffId);
    }

    // Получить SIM-карты по номеру телефона
    @RequestMapping(value = "/phone/{phoneNumber}", method = RequestMethod.GET)
    public List<SimCard> getSimCardsByPhoneNumber(@PathVariable String phoneNumber) {
        return simCardService.getSimCardsByPhoneNumber(phoneNumber);
    }

    // Получить SIM-карту по ID
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public SimCard getSimCardById(@PathVariable Long id) {
        return simCardService.getSimCardById(id)
                .orElseThrow(() -> new RuntimeException("SimCard not found"));
    }

    // Создать новую SIM-карту
    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public SimCard createSimCard(@RequestBody SimCard simCard) {
        return simCardService.createSimCard(simCard);
    }

    // Обновить SIM-карту
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    public SimCard updateSimCard(@PathVariable Long id, @RequestBody SimCard updatedSimCard) {
        return simCardService.updateSimCard(id, updatedSimCard);
    }

    // Удалить SIM-карту
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public void deleteSimCard(@PathVariable Long id) {
        simCardService.deleteSimCard(id);
    }

    // Обновить тариф для SIM-карты
    @RequestMapping(value = "/{id}/tariff", method = RequestMethod.PUT)
    public SimCard updateSimCardTariff(@PathVariable Long id, @RequestBody Tariff newTariff) {
        return simCardService.updateSimCardTariff(id, newTariff);
    }

    // получение статистики по симкам
    @GetMapping("/statistics")
    public SimCardStatisticsDto getSimCardStatistics() {
        return simCardService.getSimCardStatistics();
    }

}
