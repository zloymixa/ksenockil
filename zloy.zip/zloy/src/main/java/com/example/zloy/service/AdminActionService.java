package com.example.zloy.service;

import com.example.zloy.entities.AdminAction;
import com.example.zloy.controllers.AdminActionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminActionService {

    private final AdminActionRepository adminActionRepository;

    public AdminActionService(AdminActionRepository adminActionRepository) {
        this.adminActionRepository = adminActionRepository;
    }

    public AdminAction create(AdminAction adminAction) {
        return adminActionRepository.save(adminAction);
    }

    public List<AdminAction> getAll() {
        return adminActionRepository.findAll();
    }

    public AdminAction getById(Long id) {
        return adminActionRepository.findById(id).orElse(null);
    }
}

