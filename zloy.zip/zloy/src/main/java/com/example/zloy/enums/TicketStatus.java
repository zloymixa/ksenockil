package com.example.zloy.enums;

public enum TicketStatus {
    OPEN("открыт"),
    IN_PROGRESS("в процессе"),
    CLOSED("закрыт");

    private final String status;

    TicketStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public static TicketStatus fromString(String status) {
        for (TicketStatus ticketStatus : TicketStatus.values()) {
            if (ticketStatus.getStatus().equalsIgnoreCase(status)) {
                return ticketStatus;
            }
        }
        throw new IllegalArgumentException("Unknown status: " + status);
    }
}