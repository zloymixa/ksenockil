package com.example.zloy.controller;

import com.example.zloy.entities.Ticket;
import com.example.zloy.entities.User;
import com.example.zloy.enums.TicketStatus;
import com.example.zloy.service.TicketService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.zloy.service.UserService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("api/tickets")
public class TicketController {

    private final TicketService ticketService;
    private final UserService userService;

    public TicketController(TicketService ticketService, UserService userService) {
        this.ticketService = ticketService;
        this.userService = userService;
    }

    // Получение всех тикетов
    @GetMapping
    public List<Ticket> getAllTickets() {
        return ticketService.getAllTickets();
    }

    // Получение тикетов по статусу
    @GetMapping("/status/{status}")
    public List<Ticket> getTicketsByStatus(@PathVariable TicketStatus status) {
        return ticketService.getTicketsByStatus(status);
    }

    // Получение тикетов пользователя
    @GetMapping("/user/{userId}")
    public List<Ticket> getTicketsByUser(@PathVariable Long userId) {
        return ticketService.getTicketsByUser(userId);
    }

    // Получение тикета по ID
    @GetMapping("/{id}")
    public Optional<Ticket> getTicketById(@PathVariable Long id) {
        return ticketService.getTicketById(id);
    }

    // Создание нового тикета
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Ticket> createTicket(@RequestBody Ticket ticket) {
        if (ticket.getUser() == null || ticket.getUser().getId() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null); // Вернуть ошибку, если пользователь не передан
        }
        try {
            Ticket savedTicket = ticketService.createTicket(ticket);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedTicket);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null); // Возвращаем ошибку, если пользователь не существует в базе
        }
    }



    @PutMapping("/{id}")
    public ResponseEntity<Ticket> updateTicket(@PathVariable Long id, @RequestBody Map<String, String> updates) {
        Optional<Ticket> ticketOptional = ticketService.getTicketById(id);
        if (ticketOptional.isPresent()) {
            Ticket ticket = ticketOptional.get();

            // Обновление статуса, если он передан
            String status = updates.get("status");
            if (status != null && !status.isEmpty()) {
                try {
                    ticket.setStatus(TicketStatus.valueOf(status));  // Преобразуем строку в enum
                } catch (IllegalArgumentException e) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(null);  // Возвращаем ошибку, если статус не верен
                }
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);  // Статус не передан
            }

            // Обновляем время обновления тикета
            ticket.setUpdatedAt(LocalDateTime.now());

            // Сохраняем тикет с обновленными данными
            ticketService.updateTicket(id, ticket);

            return ResponseEntity.ok(ticket);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);  // Если тикет не найден
        }
    }




    // Удаление тикета
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTicket(@PathVariable Long id) {
        System.out.println("Удаление заявки с ID: " + id);
        ticketService.deleteTicket(id);
    }



}
