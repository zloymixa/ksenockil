package com.example.zloy.entities;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "tariffs", schema = "sim_operator_system")
public class Tariff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String description;

    private BigDecimal price;

    @Column(name = "internet_traffic")
    private Integer internetTraffic;

    private Integer minutes;

    private Integer sms;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "tariff", fetch = FetchType.LAZY)
    @JsonIgnoreProperties("tariff")  // предотвращаем рекурсию при сериализации
    private List<TariffService> tariffServices;

    // Геттеры и сеттеры

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getInternetTraffic() {
        return internetTraffic;
    }

    public void setInternetTraffic(Integer internetTraffic) {
        this.internetTraffic = internetTraffic;
    }

    public Integer getMinutes() {
        return minutes;
    }

    public void setMinutes(Integer minutes) {
        this.minutes = minutes;
    }

    public Integer getSms() {
        return sms;
    }

    public void setSms(Integer sms) {
        this.sms = sms;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<TariffService> getTariffServices() {
        return tariffServices;
    }

    public void setTariffServices(List<TariffService> tariffServices) {
        this.tariffServices = tariffServices;
    }

    // Аннотация для автоматической установки времени создания
    @PrePersist
    public void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now(); // Устанавливаем время создания
        }
        updatedAt = createdAt; // Устанавливаем время обновления как время создания
    }

    // Аннотация для автоматического обновления времени
    @PreUpdate
    public void preUpdate() {
        updatedAt = LocalDateTime.now(); // Обновляем время при изменении записи
    }
}
