package com.example.zloy.controllers;

import com.example.zloy.entities.SimCard;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface SimCardRepository extends JpaRepository<SimCard, Long> {

    // Метод для поиска всех SIM-карт по пользователю
    List<SimCard> findByUserId(Long userId);

    // Метод для поиска SIM-карт по тарифу
    List<SimCard> findByTariffId(Long tariffId);

    // Метод для поиска SIM-карт по номеру телефона
    List<SimCard> findByPhoneNumber(String phoneNumber);

    Optional<SimCard> findFirstByUserId(Long userId);  // для одной сим-карты
}