package com.example.zloy.controller;

import com.example.zloy.entities.QrPayment;
import com.example.zloy.entities.QrPaymentConfirmRequest;
import com.example.zloy.service.QrPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/qr")
public class QrPaymentController {

    private final QrPaymentService qrPaymentService;

    @Autowired
    public QrPaymentController(QrPaymentService qrPaymentService) {
        this.qrPaymentService = qrPaymentService;
    }

    @PostMapping("/create")
    public ResponseEntity<String> createPayment(@RequestBody QrPayment qrPayment) {
        boolean isCreated = qrPaymentService.createPayment(qrPayment);

        if (isCreated) {
            return ResponseEntity.ok("Payment created successfully");
        } else {
            return ResponseEntity.status(400).body("Error creating payment");
        }
    }

    @PostMapping("/confirm")
    public ResponseEntity<String> confirmPayment(@RequestBody QrPaymentConfirmRequest request) {
        boolean isSuccessful = qrPaymentService.confirmPayment(request.getConfirmationCode());

        if (isSuccessful) {
            return ResponseEntity.ok("Payment confirmed successfully");
        } else {
            return ResponseEntity.status(400).body("Invalid or already processed confirmation code");
        }
    }

    @GetMapping("/confirmation-code/{userId}")
    public ResponseEntity<String> getConfirmationCode(@PathVariable Long userId) {
        String code = qrPaymentService.getConfirmationCodeByUserId(userId);

        if (code != null) {
            return ResponseEntity.ok(code);
        } else {
            return ResponseEntity.status(404).body("No unpaid QR payment found for this user");
        }
    }

}
