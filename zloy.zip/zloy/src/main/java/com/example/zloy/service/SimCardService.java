package com.example.zloy.service;

import com.example.zloy.dto.SimCardStatisticsDto;
import com.example.zloy.entities.SimCard;
import com.example.zloy.controllers.SimCardRepository;
import com.example.zloy.entities.Tariff;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SimCardService {

    private final SimCardRepository simCardRepository;

    public SimCardService(SimCardRepository simCardRepository) {
        this.simCardRepository = simCardRepository;
    }

    // Получить все SIM-карты
    public List<SimCard> getAllSimCards() {
        List<SimCard> simCards = simCardRepository.findAll();
        simCards.forEach(this::updateSimCardDetails);  // Обновляем данные о тарифах
        return simCards;
    }

    // Получить SIM-карты по пользователю
    public List<SimCard> getSimCardsByUser(Long userId) {
        List<SimCard> simCards = simCardRepository.findByUserId(userId);
        simCards.forEach(this::updateSimCardDetails);  // Обновляем данные о тарифах
        return simCards;
    }

    // Получить SIM-карты по тарифу
    public List<SimCard> getSimCardsByTariff(Long tariffId) {
        List<SimCard> simCards = simCardRepository.findByTariffId(tariffId);
        simCards.forEach(this::updateSimCardDetails);  // Обновляем данные о тарифах
        return simCards;
    }

    // Получить SIM-карты по номеру телефона
    public List<SimCard> getSimCardsByPhoneNumber(String phoneNumber) {
        List<SimCard> simCards = simCardRepository.findByPhoneNumber(phoneNumber);
        simCards.forEach(this::updateSimCardDetails);  // Обновляем данные о тарифах
        return simCards;
    }

    // Получить SIM-карту по ID
    public Optional<SimCard> getSimCardById(Long id) {
        Optional<SimCard> simCard = simCardRepository.findById(id);
        simCard.ifPresent(this::updateSimCardDetails);  // Обновляем данные о тарифах
        return simCard;
    }

    // Создать новую SIM-карту
    public SimCard createSimCard(SimCard simCard) {
        if (simCard.getTariff() != null) {
            Tariff tariff = simCard.getTariff();
            simCard.setInternetTraffic(tariff.getInternetTraffic());
            simCard.setMinutes(tariff.getMinutes());
            simCard.setSms(tariff.getSms());
        }

        simCard.setBalance(0.0);  // Новый номер — баланс всегда 0
        simCard.setCreatedAt(LocalDateTime.now());
        simCard.setUpdatedAt(LocalDateTime.now());

        return simCardRepository.save(simCard);
    }

    // Обновить SIM-карту
    public SimCard updateSimCard(Long id, SimCard updatedSimCard) {
        return simCardRepository.findById(id).map(simCard -> {

            // User
            if (updatedSimCard.getUser() != null) {
                simCard.setUser(updatedSimCard.getUser());
            }

            // Tariff
            if (updatedSimCard.getTariff() != null) {
                simCard.setTariff(updatedSimCard.getTariff());

                Tariff tariff = updatedSimCard.getTariff();
                if (tariff.getInternetTraffic() != null) {
                    simCard.setInternetTraffic(tariff.getInternetTraffic());
                }
                if (tariff.getMinutes() != null) {
                    simCard.setMinutes(tariff.getMinutes());
                }
                if (tariff.getSms() != null) {
                    simCard.setSms(tariff.getSms());
                }
            }

            // AdditionalService
            if (updatedSimCard.getAdditionalService() != null) {
                simCard.setAdditionalService(updatedSimCard.getAdditionalService());
            }

            // PhoneNumber
            if (updatedSimCard.getPhoneNumber() != null) {
                simCard.setPhoneNumber(updatedSimCard.getPhoneNumber());
            }

            // Balance
            if (updatedSimCard.getBalance() != null) {
                simCard.setBalance(updatedSimCard.getBalance());
            }

            simCard.setUpdatedAt(LocalDateTime.now());

            return simCardRepository.save(simCard);
        }).orElseThrow(() -> new RuntimeException("SimCard not found"));
    }



    // Удалить SIM-карту
    public void deleteSimCard(Long id) {
        simCardRepository.deleteById(id);
    }

    // Метод для обновления тарифных данных в симке
    private void updateSimCardDetails(SimCard simCard) {
        if (simCard.getTariff() != null) {
            Tariff tariff = simCard.getTariff();
            simCard.setInternetTraffic(tariff.getInternetTraffic());
            simCard.setMinutes(tariff.getMinutes());
            simCard.setSms(tariff.getSms());
        }
    }

    // Обновить тариф для SIM-карты
    public SimCard updateSimCardTariff(Long id, Tariff newTariff) {
        return simCardRepository.findById(id).map(simCard -> {
            // Обновляем тариф и соответствующие параметры
            simCard.setTariff(newTariff);
            if (newTariff != null) {
                simCard.setInternetTraffic(newTariff.getInternetTraffic());
                simCard.setMinutes(newTariff.getMinutes());
                simCard.setSms(newTariff.getSms());
            }
            simCard.setUpdatedAt(LocalDateTime.now());
            return simCardRepository.save(simCard);
        }).orElseThrow(() -> new RuntimeException("SimCard not found"));
    }

    @Transactional
    public SimCardStatisticsDto getSimCardStatistics() {
        Object[] row = (Object[]) entityManager.createNativeQuery("SELECT * FROM sim_operator_system.get_sim_card_statistics()").getSingleResult();

        SimCardStatisticsDto dto = new SimCardStatisticsDto();
        dto.totalSimCards = (int) row[0];
        dto.paidSimCards = (int) row[1];
        dto.notPaidSimCards = (int) row[2];
        dto.simCardsWithServices = (int) row[3];
        dto.recentSimCards = (int) row[4];
        dto.avgInternetTraffic = row[5] != null ? ((Number) row[5]).doubleValue() : 0.0;
        dto.avgMinutes = row[6] != null ? ((Number) row[6]).doubleValue() : 0.0;
        dto.avgSms = row[7] != null ? ((Number) row[7]).doubleValue() : 0.0;
        dto.simCardsWithoutTariff = (int) row[8];
        dto.simCardsWithoutServices = (int) row[9];
        dto.avgBalance = row[10] != null ? ((Number) row[10]).doubleValue() : 0.0;

        return dto;
    }

    @PersistenceContext
    private EntityManager entityManager;

}
