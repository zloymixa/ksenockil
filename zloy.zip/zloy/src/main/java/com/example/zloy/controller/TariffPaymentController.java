package com.example.zloy.controller;


import com.example.zloy.service.TariffPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class TariffPaymentController {

    @Autowired
    private TariffPaymentService tariffPaymentService;

    @PostMapping("/deduct/{userId}")
    public ResponseEntity<String> deductPayment(@PathVariable Integer userId) {
        try {
            tariffPaymentService.deductPayment(userId);
            return ResponseEntity.ok("Оплата тарифа успешно списана.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body("Ошибка при списании оплаты: " + e.getMessage());
        }
    }
}
