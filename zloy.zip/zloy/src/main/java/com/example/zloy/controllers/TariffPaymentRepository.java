package com.example.zloy.controllers;

import com.example.zloy.entities.User;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class TariffPaymentRepository {

    private final JdbcTemplate jdbcTemplate;

    public TariffPaymentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void deductTariffPaymentByUser(Integer userId) {
        try {
            jdbcTemplate.execute(
                    "SELECT sim_operator_system.deduct_tariff_payment_by_user(" + userId + ")"
            );
        } catch (DataAccessException e) {
            // Extract the original PostgreSQL exception message
            Throwable rootCause = e.getRootCause();
            if (rootCause != null) {
                throw new RuntimeException(rootCause.getMessage());
            }
            throw new RuntimeException("Error processing tariff payment");
        }
    }
}