package com.example.zloy.service;

import com.example.zloy.entities.QrPayment;
import com.example.zloy.entities.SimCard;
import com.example.zloy.controllers.QrPaymentRepository;
import com.example.zloy.controllers.SimCardRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class QrPaymentService {

    private final QrPaymentRepository qrPaymentRepository;
    private final SimCardRepository simCardRepository;

    @Autowired
    public QrPaymentService(QrPaymentRepository qrPaymentRepository, SimCardRepository simCardRepository) {
        this.qrPaymentRepository = qrPaymentRepository;
        this.simCardRepository = simCardRepository;
    }

    @Transactional
    public boolean confirmPayment(String confirmationCode) {
        Optional<QrPayment> paymentOptional = qrPaymentRepository.findByConfirmationCodeAndIsPaidFalse(confirmationCode);

        if (paymentOptional.isEmpty()) {
            return false;  // Платеж не найден или уже оплачен
        }

        QrPayment payment = paymentOptional.get();

        // Логика пополнения баланса сим-карты пользователя
        Optional<SimCard> simCardOptional = simCardRepository.findFirstByUserId(payment.getUserId());
        if (simCardOptional.isPresent()) {
            SimCard simCard = simCardOptional.get();
            simCard.setBalance(simCard.getBalance() + payment.getAmount());  // Пополняем баланс, используя сложение
            simCardRepository.save(simCard);  // Сохраняем обновленную сим-карту
        } else {
            return false;  // Сим-карта не найдена для этого пользователя
        }

        // Обновляем статус платежа
        payment.setIsPaid(true);
        qrPaymentRepository.save(payment);

        return true;
    }

    @Transactional
    public boolean createPayment(QrPayment qrPayment) {
        // Генерация случайного кода подтверждения
        String confirmationCode = "QR" + UUID.randomUUID().toString().substring(0, 8);

        // Заполнение данных для нового платежа
        qrPayment.setConfirmationCode(confirmationCode);
        qrPayment.setIsPaid(false);

        // Сохраняем новый платеж в базу данных
        qrPaymentRepository.save(qrPayment);

        return true;
    }

    public String getConfirmationCodeByUserId(Long userId) {
        Optional<QrPayment> paymentOptional = qrPaymentRepository
                .findFirstByUserIdAndIsPaidFalseOrderByCreatedAtDesc(userId);

        return paymentOptional.map(QrPayment::getConfirmationCode).orElse(null);
    }





}
