package com.example.zloy.controller;

import com.example.zloy.service.TariffChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tariffs")
public class TariffChangeController {

    @Autowired
    private TariffChangeService tariffChangeService;

    // Изменить тариф по имени
    @PostMapping("/change")
    public void changeTariff(@RequestParam int userId, @RequestParam String newTariff) {
        tariffChangeService.changeTariff(userId, newTariff);
    }

    // Изменить тариф по ID
    @PostMapping("/changeById")
    public void changeTariffById(@RequestParam int userId, @RequestParam int newTariffId) {
        tariffChangeService.changeTariffById(userId, newTariffId);
    }
}
