package com.example.zloy.controllers;

import com.example.zloy.entities.TariffService;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TariffServiceRepository extends JpaRepository<TariffService, Long> {
    List<TariffService> findByTariffId(Long tariffId);
    List<TariffService> findByServiceId(Long serviceId);
}