package com.example.zloy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZloyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZloyApplication.class, args);
	}

}
