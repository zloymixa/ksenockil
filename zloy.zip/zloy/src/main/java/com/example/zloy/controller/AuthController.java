package com.example.zloy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public AuthController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
        try {
            // --- Проверка на администратора ---
            if ((request.getLogin().equals("+79999999999") || request.getLogin().equals("admin@ksenon.com"))
                    && request.getPassword().equals("admin")) {

                Map<String, Object> adminInfo = new HashMap<>();
                adminInfo.put("role", "admin");
                adminInfo.put("name", "Administrator");

                return ResponseEntity.ok(Map.of(
                        "success", true,
                        "userInfo", adminInfo
                ));
            }
            // -----------------------------------

            boolean isEmail = request.getLogin().contains("@");

            String sql = isEmail
                    ? "SELECT sim_operator_system.login_by_email(?, ?)"
                    : "SELECT sim_operator_system.login_by_phone(?, ?)";

            String result = jdbcTemplate.queryForObject(
                    sql,
                    new Object[]{request.getLogin(), request.getPassword()},
                    (rs, rowNum) -> rs.getString(1)
            );

            if (result.startsWith("Invalid")) {
                return ResponseEntity.status(401).body(Map.of(
                        "success", false,
                        "message", result
                ));
            } else {
                return ResponseEntity.ok(Map.of(
                        "success", true,
                        "userInfo", parseUserInfo(result)
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "message", "Server error: " + e.getClass().getSimpleName() + ": " + e.getMessage()
            ));
        }
    }

    private Map<String, Object> parseUserInfo(String dbResult) {
        Map<String, Object> info = new HashMap<>();
        String[] parts = dbResult.split(", ");

        for (String part : parts) {
            String[] keyValue = part.split(": ");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();

                // Нормализация ключа (удаляем пробелы и приводим к нижнему регистру)
                String normalizedKey = key.replace(" ", "").toLowerCase();

                if (isNumericField(normalizedKey)) {
                    processNumericField(info, normalizedKey, value);
                } else {
                    info.put(normalizedKey, value);
                }
            }
        }
        return info;
    }

    private boolean isNumericField(String key) {
        // Проверяем в lowercase, чтобы избежать проблем с регистром
        return key.equals("internettraffic") || key.equals("minutes")
                || key.equals("sms") || key.equals("balance");
    }

    private void processNumericField(Map<String, Object> info, String key, String value) {
        String numericString = value.replaceAll("[^0-9.-]", "");

        try {
            double numericValue = Double.parseDouble(numericString);

            switch (key) {
                case "internettraffic":
                    info.put("internetTraffic", String.format("%.0f ГБ", numericValue)); // "200 ГБ"
                    break;
                case "minutes":
                    info.put("minutes", String.format("%d мин", (int) numericValue)); // "1000 мин"
                    break;
                case "sms":
                    info.put("sms", String.format("%d шт", (int) numericValue)); // "1000 шт"
                    break;
                case "balance":
                    info.put("balance", String.format("%.2f ₽", numericValue)); // "1500.00 ₽"
                    break;
                default:
                    info.put(key, numericValue);
            }
        } catch (NumberFormatException e) {
            info.put(key, value);
        }
    }

    public static class LoginRequest {
        private String login;
        private String password;

        // Геттеры и сеттеры
        public String getLogin() { return login; }
        public void setLogin(String login) { this.login = login; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }
}
