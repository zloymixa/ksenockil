package com.example.zloy.controller;

import com.example.zloy.entities.AdminAction;
import com.example.zloy.service.AdminActionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/admin-actions")

public class AdminActionController {

    private final AdminActionService adminActionService;

    public AdminActionController(AdminActionService adminActionService) {
        this.adminActionService = adminActionService;
    }

    @PostMapping
    public AdminAction create(@RequestBody AdminAction adminAction) {
        return adminActionService.create(adminAction);
    }

    @GetMapping
    public List<AdminAction> getAll() {
        return adminActionService.getAll();
    }

    @GetMapping("/{id}")
    public AdminAction getById(@PathVariable Long id) {
        return adminActionService.getById(id);
    }
}