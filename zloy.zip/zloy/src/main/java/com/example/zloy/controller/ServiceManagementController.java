package com.example.zloy.controller;

import com.example.zloy.service.ServiceManagementService;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/services")
public class ServiceManagementController {

    private final ServiceManagementService serviceManagementService;
    private final JdbcTemplate jdbcTemplate;

    public ServiceManagementController(ServiceManagementService serviceManagementService,
                                       JdbcTemplate jdbcTemplate) {
        this.serviceManagementService = serviceManagementService;
        this.jdbcTemplate = jdbcTemplate;
    }

    // Получение всех доступных услуг
    @GetMapping("/additional")
    public List<Map<String, Object>> getAllAdditionalServices() {
        String sql = "SELECT id, name, description, price FROM additional_services";
        return jdbcTemplate.queryForList(sql);
    }

    // Подключение услуги пользователю
    @PostMapping("/add")
    public ResponseEntity<String> addService(@RequestParam int userId,
                                             @RequestParam int serviceId) {
        try {
            serviceManagementService.addService(userId, serviceId);
            return ResponseEntity.ok("Услуга успешно подключена.");
        } catch (Exception e) {
            return ResponseEntity.status(500)
                    .body("Ошибка при подключении услуги: " + e.getMessage());
        }
    }
}

