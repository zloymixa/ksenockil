package com.example.zloy.service;

import com.example.zloy.entities.Ticket;
import com.example.zloy.controllers.TicketRepository;
import com.example.zloy.enums.TicketStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;

    public TicketService(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }

    // Получение всех тикетов
    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }

    // Получение тикетов по статусу
    public List<Ticket> getTicketsByStatus(TicketStatus status) {
        return ticketRepository.findByStatus(status.getStatus());
    }

    // Получение тикетов пользователя
    public List<Ticket> getTicketsByUser(Long userId) {
        return ticketRepository.findByUserId(userId);
    }

    // Получение тикета по ID
    public Optional<Ticket> getTicketById(Long id) {
        return ticketRepository.findById(id);
    }

    // Создание нового тикета
    public Ticket createTicket(Ticket ticket) {
        ticket.setCreatedAt(LocalDateTime.now());  // Устанавливаем время создания
        ticket.setUpdatedAt(LocalDateTime.now());  // Устанавливаем время обновления
        return ticketRepository.save(ticket);
    }

    // Обновление тикета
    public Ticket updateTicket(Long id, Ticket updatedTicket) {
        return ticketRepository.findById(id).map(ticket -> {
            ticket.setTitle(updatedTicket.getTitle());
            ticket.setDescription(updatedTicket.getDescription());
            ticket.setStatus(updatedTicket.getStatus());
            ticket.setUpdatedAt(LocalDateTime.now());  // Обновляем поле updated_at
            return ticketRepository.save(ticket);
        }).orElseThrow(() -> new RuntimeException("Ticket not found"));
    }

    // Удаление тикета
    public void deleteTicket(Long id) {
        ticketRepository.deleteById(id);
    }

    // Обновление статуса тикета
    public Ticket updateTicketStatus(Long id, TicketStatus status) {
        return ticketRepository.findById(id).map(ticket -> {
            ticket.setStatus(status);
            ticket.setUpdatedAt(LocalDateTime.now());  // Обновляем время обновления
            return ticketRepository.save(ticket);
        }).orElseThrow(() -> new RuntimeException("Ticket not found"));
    }

}