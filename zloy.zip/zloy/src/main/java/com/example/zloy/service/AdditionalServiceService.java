package com.example.zloy.service;

import com.example.zloy.entities.AdditionalService;

import java.util.List;

public interface AdditionalServiceService {
    List<AdditionalService> getAll();
    AdditionalService getById(Long id);
    AdditionalService create(AdditionalService service);
    AdditionalService update(Long id, AdditionalService updatedService);
    void delete(Long id);
}
