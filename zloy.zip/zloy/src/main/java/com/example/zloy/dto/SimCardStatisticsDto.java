package com.example.zloy.dto;

public class SimCardStatisticsDto {
    public int totalSimCards;
    public int paidSimCards;
    public int notPaidSimCards;
    public int simCardsWithServices;
    public int recentSimCards;
    public double avgInternetTraffic;
    public double avgMinutes;
    public double avgSms;
    public int simCardsWithoutTariff;
    public int simCardsWithoutServices;
    public double avgBalance;
}