package com.example.zloy.service;

import com.example.zloy.entities.TariffService;
import com.example.zloy.entities.Tariff;
import com.example.zloy.entities.AdditionalService;
import com.example.zloy.controllers.TariffServiceRepository;
import com.example.zloy.controllers.TariffRepository;
import com.example.zloy.controllers.AdditionalServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TariffServiceService {

    private final TariffServiceRepository tariffServiceRepository;
    private final TariffRepository tariffRepository;
    private final AdditionalServiceRepository additionalServiceRepository;

    @Autowired
    public TariffServiceService(TariffServiceRepository tariffServiceRepository,
                                TariffRepository tariffRepository,
                                AdditionalServiceRepository additionalServiceRepository) {
        this.tariffServiceRepository = tariffServiceRepository;
        this.tariffRepository = tariffRepository;
        this.additionalServiceRepository = additionalServiceRepository;
    }

    // Добавление услуги в тариф
    public TariffService addServiceToTariff(Long tariffId, Long serviceId) {
        Tariff tariff = tariffRepository.findById(tariffId)
                .orElseThrow(() -> new RuntimeException("Tariff not found"));
        AdditionalService service = additionalServiceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("Service not found"));

        TariffService tariffService = new TariffService(tariff, service);
        return tariffServiceRepository.save(tariffService);
    }

    // Удаление услуги из тарифа
    public void removeServiceFromTariff(Long tariffServiceId) {
        tariffServiceRepository.deleteById(tariffServiceId);
    }

    // Получить все услуги для тарифа
    public List<TariffService> getServicesByTariff(Long tariffId) {
        return tariffServiceRepository.findByTariffId(tariffId);
    }

    // Получить все тарифы для услуги
    public List<TariffService> getTariffsByService(Long serviceId) {
        return tariffServiceRepository.findByServiceId(serviceId);
    }
}