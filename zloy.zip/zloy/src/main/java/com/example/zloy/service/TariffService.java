package com.example.zloy.service;

import com.example.zloy.entities.Tariff;
import com.example.zloy.controllers.TariffRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TariffService {

    private final TariffRepository tariffRepository;

    public TariffService(TariffRepository tariffRepository) {
        this.tariffRepository = tariffRepository;
    }

    public List<Tariff> getAllTariffs() {
        return tariffRepository.findAll();
    }

    public Optional<Tariff> getTariffById(Long id) {
        return tariffRepository.findById(id);
    }

    public Tariff createTariff(Tariff tariff) {
        return tariffRepository.save(tariff);
    }

    public Tariff updateTariff(Long id, Tariff updatedTariff) {
        return tariffRepository.findById(id).map(tariff -> {
            tariff.setName(updatedTariff.getName());
            tariff.setDescription(updatedTariff.getDescription());
            tariff.setPrice(updatedTariff.getPrice());
            tariff.setInternetTraffic(updatedTariff.getInternetTraffic());
            tariff.setMinutes(updatedTariff.getMinutes());
            tariff.setSms(updatedTariff.getSms());
            tariff.setUpdatedAt(updatedTariff.getUpdatedAt());
            return tariffRepository.save(tariff);
        }).orElseThrow(() -> new RuntimeException("Tariff not found"));
    }

    public void deleteTariff(Long id) {
        tariffRepository.deleteById(id);
    }
}