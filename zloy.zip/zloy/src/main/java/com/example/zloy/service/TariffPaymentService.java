package com.example.zloy.service;

import com.example.zloy.controllers.TariffPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TariffPaymentService {

    @Autowired
    private TariffPaymentRepository tariffPaymentRepository;

    public void deductPayment(Integer userId) throws RuntimeException {
        tariffPaymentRepository.deductTariffPaymentByUser(userId);
    }
}