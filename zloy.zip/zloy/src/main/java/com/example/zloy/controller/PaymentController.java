package com.example.zloy.controller;

import com.example.zloy.entities.Payment;
import com.example.zloy.service.PaymentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")

public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Создать платеж для пользователя
    @PostMapping("/user/{userId}")
    public Payment createPayment(@PathVariable Long userId, @RequestBody Payment payment) {
        return paymentService.createPayment(userId, payment);
    }

    // Получить все платежи
    @GetMapping
    public List<Payment> getAllPayments() {
        return paymentService.getAllPayments();
    }

    // Получить платежи конкретного пользователя
    @GetMapping("/user/{userId}")
    public List<Payment> getPaymentsByUser(@PathVariable Long userId) {
        return paymentService.getPaymentsByUserId(userId);
    }

    // Получить конкретный платеж по ID
    @GetMapping("/{id}")
    public Payment getPayment(@PathVariable Long id) {
        return paymentService.getPaymentById(id);
    }
}